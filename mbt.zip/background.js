// $(document).ready(function () {\

chrome.browserAction.onClicked.addListener(btnClicked);

function btnClicked(tab) {
    console.log('icon clicked')
    console.log(tab)
    let msg = {
        txt: "hi from send message"

    }
    chrome.tabs.sendMessage(tab.id, msg);
}

//    chrome.runtime.onInstalled.addListener(function () {
//        for (let key of Object.keys(kLocales)) {
//         //    console.log(key)
//            chrome.contextMenus.create({
//                id: key,
//                title: kLocales[key],
//                type: 'normal',
//                contexts: ['all'],
//            });
//        }
//    });


// chrome.contextMenus.onClicked.addListener(selectedFalseOnClick)

//    function selectedFalseOnClick(info, tab) {
//     findFroms()
//    }

//      const kLocales = {
//          'start': 'Start Testing'
//      };




// function findFroms(){
//     var forms = $('body').html()//.find('form').remove()
//     console.log("forms:")
//     console.log(forms)
// }


// })

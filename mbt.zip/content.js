var indexedDB = window.indexedDB || window.webkitIndexedDB ||
    window.mozIndexedDB || window.msIndexedDB;
var IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction;
var db;
var request;

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        //  console.log('slaw')
        // console.log(request)

        switch (request.type) {
        
            case "get_data":
                //    console.log('get data')
                getData();
                break;
            case "delete_database":
                //    console.log('get data')
               indexedDB.deleteDatabase('trackingDataMain')
               location.reload()
                break;

                 case "reload":
                //    console.log('get data')
               location.reload()
                break;


        }
    });
chrome.storage.sync.get(["testing_url", "testing_status"], function (res) {
    // alert(res.testing_status)
    if (res.testing_status == 1) {
          $("body").css({
                      "background": "#f3ffd1"
                  })
        $("a,button,input,checkbox,radio,select").css({
            "border": "1px solid red"
        })
    }else{
 $("body").css({
     "background": ""
 })
  $("a,button,input,checkbox,radio,select").css({
      "border": ""
  })
    }








$("document").ready(function () {





    chrome.storage.sync.get(["testing_url", "testing_status"], function (res) {
                // alert(res.testing_status)
                if (res.testing_status == 1) {

                      window.webkitRequestFileSystem(window.TEMPORARY, 1024*1024, function(fs) {
    // creating
      fs.root.getFile('model.json', {create: false}, function(fileEntry) {

        fileEntry.remove(function() {
          console.log('File removed.');
        }, errorHandler);

      }, errorHandler);

  });


  $('body').bind('click dblclick keydown',
      function (e) {
        var notify= {
            type:"basic",
            title:"click",
            message:"testing"
        }  
        //chrome.notifications.create("limitNotif", notify)

         
        // console.log(document.referrer)
        if ((document.referrer+"") != '') {
            Addr = document.referrer
            //  alert("ref="+document.referrer);
        }else{
            Addr = window.location.href
            //  alert("addr="+Addr);
        }
          // console.log(e.target.localName);
          // console.log(e);
          // console.log(e.type);


            // alert("window : " + window.location.href)
            // alert("Addr : "+ Addr)
            // alert("target : " + e.target.href)
            // // alert(JSON.stringify(e))
            // alert("currentTarget : " + e.currentTarget.baseURI)
        //   chrome.storage.sync.get("prevAddr", function (res) {
        //     Addr = res.prevAddr
        // alert(Addr)
        if (e.target.localName == "a") {
            Addr = e.target.href
        }
        if (e.target.localName == "body" || e.target.localName == "input" || e.target.localName == 'radio' || e.target.localName == 'checkbox' || e.target.localName=='select') {
            Addr = window.location.href
        }
              var arr = {
                  "AddressUrl": window.location.href,
                  "FromAddressUrl": Addr,
                  "screenShoot": "",
                  "event": e.type,
                  "element": e.target.localName,
                  "DateTime": new Date().toLocaleString(),
              }
              addToDB(arr);

 //jsonResult = getData();
              getData(); 


              // for auto
        //       chrome.storage.sync.set({
        //           "prevAddr": window.location.href
        //       })
        //   })

          


      });
    }
})

})

})


function destroyClickedElement(event) {
    document.body.removeChild(event.target);
}

function getData() {
     // initDb();
    // alert();
    request = indexedDB.open("trackingDataMain");
    request.onerror = function (event) {
        alert("Why didn't you allow my web app to use IndexedDB?!");
    };



    request.onsuccess = function (event) {
       
        db = event.target.result;
        var transaction = db.transaction(["tests"], "readwrite");
        var objectStore = transaction.objectStore("tests");
        var results = "";
        var resultsNodes = "";
        var ur_arr=[];
        var oldAddr = ""
        objectStore.getAll().onsuccess = function (event) {

            //alert()
           
            event.target.result.forEach(value => {
                 // console.log( value);
                 if (!ur_arr.includes(value.AddressUrl)) {
                    ur_arr.push(value.AddressUrl)
                    // console.log(ur_arr)
                    // console.log(oldAddr +"!=="+ value.AddressUrl)
                resultsNodes += `{ "key": "` + value.AddressUrl + `","title": "` + value.AddressUrl + `","color":"skyblue" },`
                // oldAddr = value.AddressUrl
                }

                results += `{ "from": "` + value.FromAddressUrl + `","to": "` + value.AddressUrl + `", "screenShoot": "` + value.screenShoot + `","text": "` + value.event + `","element": "` + value.element + `","DateTime": "` + value.DateTime + `"},`

            });

            results = results.slice(0, -1);
            resultsNodes = resultsNodes.slice(0, -1);
            var resNode = '{"nodes" : [' + resultsNodes + ']';
            var res = '"links" : [' + results + ']}';

            AllResult = resNode + "," + res

              
               
       
          

           // saveTextAsFile1(AllResult)
     



 


    
        
  // console.log(AllResult)
        
    window.webkitRequestFileSystem(window.TEMPORARY, 1024*1024, function(fs) {
    // creating
      // fs.root.getFile('model.json', {create: false}, function(fileEntry) {

      //   fileEntry.remove(function() {
      //     console.log('File removed.');
      //   }, errorHandler);

      // }, errorHandler);



    // reading
    // fs.root.getFile('model.txt', {}, function(fileEntry) {

    //     // Get a File object representing the file,
    //     // then use FileReader to read its contents.
    //     fileEntry.file(function(file) {
    //        var reader = new FileReader();

    //        // reader.onloadend = function(e) {
    //        //   var txtArea = document.createElement('textarea');
    //        //   txtArea.value = this.result;
    //        //   document.body.appendChild(txtArea);
    //        // };

    //        reader.readAsText(file);

    //          // alert(fileEntry.toURL())



    //     }, errorHandler);

    //   }, errorHandler);

      
    // writing
       fs.root.getFile('model.json', {create: true}, function(fileEntry) {

        // Create a FileWriter object for our FileEntry (log.txt).
        fileEntry.createWriter(function(fileWriter) {
     // console.log(fileEntry.toURL())
     chrome.storage.sync.set({"testing_url_file":fileEntry.toURL()});
         // fileWriter.seek(fileWriter.length); // Start write position at EOF.

          // Create a new Blob and write it to log.txt.
         
          // console.log(jsonResult)
          var blob = new Blob([AllResult]);

          fileWriter.write(blob);

        }, errorHandler);

      }, errorHandler);



      }, errorHandler);
            };

        };


}





function saveTextAsFile1(tree) {
    var textToSave = tree
    var textToSaveAsBlob = new Blob([textToSave], {
        type: "text/plain"
    });
    var textToSaveAsURL = window.URL.createObjectURL(textToSaveAsBlob);
    var fileNameToSaveAs = 'result.json'

    var downloadLink = document.createElement("a");
    downloadLink.download = fileNameToSaveAs;
    downloadLink.innerHTML = "Download File";
    downloadLink.href = textToSaveAsURL;
    downloadLink.onclick = destroyClickedElement;
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
}


function errorHandler(e) {
  var msg = '';

  // switch (e.code) {
  //   case FileError.QUOTA_EXCEEDED_ERR:
  //     msg = 'QUOTA_EXCEEDED_ERR';
  //     break;
  //   case FileError.NOT_FOUND_ERR:
  //     msg = 'NOT_FOUND_ERR';
  //     break;
  //   case FileError.SECURITY_ERR:
  //     msg = 'SECURITY_ERR';
  //     break;
  //   case FileError.INVALID_MODIFICATION_ERR:
  //     msg = 'INVALID_MODIFICATION_ERR';
  //     break;
  //   case FileError.INVALID_STATE_ERR:
  //     msg = 'INVALID_STATE_ERR';
  //     break;
  //   default:
  //     msg = 'Unknown Error';
  //     break;
  // };

  console.log('Error: ' + e);
}


function addToDB(sendDateArr) {
    initDb();
    // console.log(sendDateArr)

    request = indexedDB.open("trackingDataMain");
    request.onerror = function (event) {
        alert("Why didn't you allow my web app to use IndexedDB?!");
    };
    request.onsuccess = function (event) {
        db = event.target.result;
        var transaction = db.transaction(["tests"], "readwrite");
        var objectStore = transaction.objectStore("tests");

        try {
            var request = objectStore.add(sendDateArr);
        } catch (e) {
            if (e.name == 'DataCloneError')
                alert("This engine doesn't know how to clone a Blob, " +
                    "use Firefox");
            throw e;
        }

        request.onsuccess = function (evt) {
            //   alert("Insertion in DB successful");
        };
        request.onerror = function () {
            alert("addPublication error:" + this.error);
        };

    }
}
function initDb() {
    // alert("DB INIT")
    request = indexedDB.open("trackingDataMain", 1);
    request.onsuccess = function (evt) {  
       // console.log(evt)
        // var db = request.result;
        db = event.target.result
    };

    request.onerror = function (evt) {
        alert("IndexedDB error: " + evt.target.errorCode);
    };

    request.onupgradeneeded = function (evt) {
        var objectStore = evt.currentTarget.result.createObjectStore(
            "tests", {
                keyPath: "id",
                autoIncrement: true
            });


        objectStore.createIndex("AddressUrl", "AddressUrl", {
            unique: false
        });

        objectStore.createIndex("FromAddressUrl", "FromAddressUrl", {
            unique: false
        });
        objectStore.createIndex("screenShoot", "screenShoot", {
            unique: false
        });
        objectStore.createIndex("event", "event", {
            unique: false
        });
        objectStore.createIndex("element", "element", {
            unique: false
        });

        objectStore.createIndex("DateTime", "DateTime", {
            unique: false
        });

        //  for (i in peopleData) {
        //      objectStore.add(peopleData[i]);
        //  }
    };
}
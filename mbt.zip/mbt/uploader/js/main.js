(function() {

    $(".dropzone").dropzone({
        url: 'uploader/upload.php',
        margin: 0,
        params:{
            'action': 'save'
        },
        success: function(res, index){
            console.log(res, index);
            // location.reload()
            location.reload(true);

        }
    });


}());

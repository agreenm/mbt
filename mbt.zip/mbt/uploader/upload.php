<?php

    echo "<pre>";
    print_r($_FILES);
    print_r($_POST);
    echo "</pre>";

    if(!move_uploaded_file($_FILES['files']['tmp_name'][0], '../minimal.json')){
        echo "error";
    }
    echo "success";
?>


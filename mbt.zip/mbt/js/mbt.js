 init();
var file_url = "";


 function init() {
    if (window.goSamples) goSamples();  // init for these samples -- you don't need to call this
    var $ = go.GraphObject.make;  // for conciseness in defining templates
    myDiagram = $(go.Diagram, "myDiagramDiv",  // create a Diagram for the DIV HTML element
                  {
                    initialDocumentSpot: go.Spot.TopCenter,
                    initialViewportSpot: go.Spot.TopCenter,
                    initialContentAlignment: go.Spot.Center,  // center the content
                    "commandHandler.copiesTree": true,
                    "undoManager.isEnabled": true,  // enable undo & redo
                    layout: 
                      // $(go.TreeLayout,
                      //   { angle: 90,
                      //     nodeSpacing: 50,
                      //     layerSpacing: 90,

                      //     // layerStyle: go.TreeLayout.LayerUniform,
                      //     //  comparer: go.LayoutVertex.smartComparer 
                      //   })
                      $(go.TreeLayout,
          {
            treeStyle: go.TreeLayout.StyleLayered,
            arrangement: go.TreeLayout.ArrangementHorizontal,
            // properties for most of the tree:
            angle: 90,
            nodeSpacing: 140,
            layerSpacing: 70,
            arrangementSpacing: new go.Size(270, 270),
            // properties for the "last parents":
            alternateAngle: 90,
            alternateLayerSpacing: 100,
            alternateAlignment: go.TreeLayout.AlignmentCenterChildren,
            alternateNodeSpacing: 270
          }),

                  });

  // myDiagram.isReadOnly = true;

    // define a simple Node template
     // define the Node template
      // myDiagram.nodeTemplate =
      //   $(go.Node, "Auto",
      //     new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
      //     // define the node's outer shape, which will surround the TextBlock
      //     $(go.Shape, "RoundedRectangle",
      //       {
      //         parameter1: 20,  // the corner has a large radius
      //         fill: $(go.Brush, "Linear", { 0: "rgb(254, 201, 0)", 1: "rgb(254, 162, 0)" }),
      //         stroke: null,
      //         portId: "",  // this Shape is the Node's port, not the whole Node
      //         fromLinkable: true, fromLinkableSelfNode: true, fromLinkableDuplicates: true,
      //         toLinkable: true, toLinkableSelfNode: true, toLinkableDuplicates: true,
      //         cursor: "pointer"
      //       }),
      //     $(go.TextBlock,
      //       {
      //         font: "bold 11pt helvetica, bold arial, sans-serif",
      //         editable: true  // editing the text automatically updates the model data
      //       },
      //       new go.Binding("text").makeTwoWay())
      //   );


    myDiagram.nodeTemplate =

      $(go.Node,
        "Auto",  // the Shape will go around the TextBlock
         { locationSpot: go.Spot.Center,  // Node.location is the center of the Shape
          // locationObjectName: "SHAPE",
          // selectionAdorned: false,
          selectionChanged: nodeSelectionChanged },

        new go.Binding("location", "loc"),  // get the Node.location from the data.loc value

        $(go.Shape, "RoundedRectangle", {
           parameter1: 50,  // the corner has a large radius
          width: 110, 
          height: 50,
            fill: "NAVY",
            stroke: null,
            portId: "",  // this Shape is the Node's port, not the whole Node
            // fromLinkable: true, fromLinkableSelfNode: true, fromLinkableDuplicates: true,
            // toLinkable: true, toLinkableSelfNode: true, toLinkableDuplicates: true,
            cursor: "pointer"
          },
 
          // Shape.fill is bound to Node.data.color
          // new go.Binding("fill", "color")
        // new go.Binding("fill", "isSelected", function(s, obj) { return s ? "#4cae4c" : $(go.Brush, "Linear", "#2e6da4"); }).ofObject()),
      new go.Binding("fill", "isSelected", function(s, obj) { return s ? "MAROON" : $(go.Brush, "Linear", { 0: "rgb(0, 0, 128)", 1: "rgb(0, 0, 128)" }); }).ofObject()

          ),
  
        $(go.TextBlock,{ 
          name: "GROUPTEXT",
          stroke:"#FFFFFF",
          overflow: go.TextBlock.OverflowClip /* the default value */,
         // maxLines: 2,
          font: "bold 6pt helvetica, bold arial, sans-serif",
          margin: 0,
          width: 90
          },  // some room around the text
          // TextBlock.text is bound to Node.data.key
          new go.Binding("text", "title")),

      );


    // define the Link template
    myDiagram.linkTemplate =$(go.Link,  // the whole link panel
          {
            curve: go.Link.Bezier, adjusting: go.Link.Stretch,
            reshapable: true, relinkableFrom: true, relinkableTo: true,
            toShortLength: 3
          },
          new go.Binding("points").makeTwoWay(),
          new go.Binding("curviness"),
          $(go.Shape,  // the link shape
            { strokeWidth: 1.5 }),
          $(go.Shape,  // the arrowhead
            { toArrow: "standard", stroke: null }),
          $(go.Panel, "Auto",
            $(go.Shape,  // the label background, which becomes transparent around the edges
              {
                fill: $(go.Brush, "Radial",
                  { 0: "rgb(255, 255, 255)", 0.3: "rgb(255, 255, 255)", 1: "rgba(255, 255, 255, 0)" }),
                stroke: null
              }),
            $(go.TextBlock, "transition",  // the label text
              {
                textAlign: "center",
                font: "6pt helvetica, arial, sans-serif",
                margin: 4,
                editable: true  // enable in-place editing
              },
              // editing the text automatically updates the model data
              new go.Binding("text").makeTwoWay())
          )
        );
      // $(go.Link,
      //   {
      //     selectable: false,      // links cannot be selected by the user
      //     curve: go.Link.Bezier,
      //     layerName: "Background"  // don't cross in front of any nodes
      //   },
      //   $(go.Shape,  // this shape only shows when it isHighlighted
      //     { isPanelMain: true, stroke: null, strokeWidth: 5 },
      //     new go.Binding("stroke", "isHighlighted", function(h) { return h ? "red" : null; }).ofObject()),
      //   $(go.Shape,
      //     // mark each Shape to get the link geometry with isPanelMain: true
      //     {name: "OBJSHAPE", isPanelMain: true, stroke: "gray", strokeWidth: 1 },
      //     new go.Binding("stroke", "color")),
      //   $(go.Shape, { name: "ARWSHAPE", toArrow: "Standard" }),
      //       //  $(go.Shape,  //  the link shape
      //       // { name: "OBJSHAPE" }),
       
      // );



// jQuery.getJSON("minimal.json", load);
chrome.storage.sync.get(["testing_url_file", "testing_status"], function (res) {
  file_url = (res.testing_url_file)
  jQuery.getJSON(file_url, load);
})

          
 function load(jsondata) {

  console.log(jsondata)
    // create the model from the data in the JavaScript object parsed from JSON text
    myDiagram.model = new go.GraphLinksModel(jsondata["nodes"], jsondata["links"]);


// myDiagram.commandHandler.selectAll();
// myDiagram.selectCollection({key:'http://localhost/testing/',key:'http://localhost/testing/'});
// myDiagram.select(myDiagram.findNodeForKey(jsondata["nodes"][0]['key']));
// myDiagram.select(myDiagram.findNodeForKey("http://localhost/testing2/"));
// alert()

  // updateHighlights('linksIn')
// deleteNode();

  }


 myDiagram.toolManager.clickSelectingTool.standardMouseSelect = function() {
  // alert(1)
      var diagram = this.diagram;
      if (diagram === null || !diagram.allowSelect)
      {
        // alert(2)
        return; 
      }
      var e = diagram.lastInput;

      var count = diagram.selection.count;
      var curobj = diagram.findPartAt(e.documentPoint, false);

   
      if (curobj !== null) {
        // alert('1')
        if (count < 2) {  // add the part to the selection
          if (!curobj.isSelected) {
            var part = curobj;
            if (part !== null) part.isSelected = true;
          }
        } else {
          if (!curobj.isSelected) {
            var part = curobj;
            if (part !== null) diagram.select(part);
          }
        }
      } else if (e.left && !(e.control || e.meta) && !e.shift) {
        // alert("cleared")
        // left click on background with no modifier: clear selection
        diagram.clearSelection();
      }
    }
  }


  // There are three bits of functionality here:
  // 1: findDistances(Node) computes the distance of each Node from the given Node.
  //    This function is used by showDistances to update the model data.
  // 2: findShortestPath(Node, Node) finds a shortest path from one Node to another.
  //    This uses findDistances.  This is used by highlightShortestPath.
  // 3: collectAllPaths(Node, Node) produces a collection of all paths from one Node to another.
  //    This is used by listAllPaths.  The result is remembered in a global variable
  //    which is used by highlightSelectedPath.  This does not depend on findDistances.

  // Returns a Map of Nodes with distance values from the given source Node.
  // Assumes all links are unidirectional.
 function findDistances(source) {
    var diagram = source.diagram;
    // keep track of distances from the source node
    var distances = new go.Map(go.Node, "number");
    // all nodes start with distance Infinity
    var nit = diagram.nodes;
    while (nit.next()) {
      var n = nit.value;
      distances.add(n, Infinity);
    }
    // the source node starts with distance 0
    distances.add(source, 0);
    // keep track of nodes for which we have set a non-Infinity distance,
    // but which we have not yet finished examining
    var seen = new go.Set(go.Node);
    seen.add(source);

    // keep track of nodes we have finished examining;
    // this avoids unnecessary traversals and helps keep the SEEN collection small
    var finished = new go.Set(go.Node);
    while (seen.count > 0) {
      // look at the unfinished node with the shortest distance so far
      var least = leastNode(seen, distances);
      var leastdist = distances.getValue(least);
      // by the end of this loop we will have finished examining this LEAST node
      seen.remove(least);
      finished.add(least);
      // look at all Links connected with this node
      var it = least.findLinksOutOf();
      while (it.next()) {
        var link = it.value;
        var neighbor = link.getOtherNode(least);
        // skip nodes that we have finished
        if (finished.contains(neighbor)) continue;
        var neighbordist = distances.getValue(neighbor);
        // assume "distance" along a link is unitary, but could be any non-negative number.
        var dist = leastdist + 1;  //Math.sqrt(least.location.distanceSquaredPoint(neighbor.location));
        if (dist < neighbordist) {
          // if haven't seen that node before, add it to the SEEN collection
          if (neighbordist === Infinity) {
            seen.add(neighbor);
          }
          // record the new best distance so far to that node
          distances.add(neighbor, dist);
        }
      }
    }

    return distances;
  }

  // This helper function finds a Node in the given collection that has the smallest distance.
  function leastNode(coll, distances) {
    var bestdist = Infinity;
    var bestnode = null;
    var it = coll.iterator;
    while (it.next()) {
      var n = it.value;
      var dist = distances.getValue(n);
      if (dist < bestdist) {
        bestdist = dist;
        bestnode = n;
      }
    }
    return bestnode;
  }


  // Find a path that is shortest from the BEGIN node to the END node.
  // (There might be more than one, and there might be none.)
  function findShortestPath(begin, end) {
    // compute and remember the distance of each node from the BEGIN node
    distances = findDistances(begin);

    // now find a path from END to BEGIN, always choosing the adjacent Node with the lowest distance
    var path = new go.List();
    path.add(end);
    while (end !== null) {
      var next = leastNode(end.findNodesInto(), distances);
      if (next !== null) {
        if (distances.getValue(next) < distances.getValue(end)) {
          path.add(next);  // making progress towards the beginning
        } else {
          next = null;  // nothing better found -- stop looking
        }
      }
      end = next;
    }
    // reverse the list to start at the node closest to BEGIN that is on the path to END
    // NOTE: if there's no path from BEGIN to END, the first node won't be BEGIN!
    path.reverse();


    return path;
  }


  // Recursively walk the graph starting from the BEGIN node;
  // when reaching the END node remember the list of nodes along the current path.
  // Finally return the collection of paths, which may be empty.
  // This assumes all links are unidirectional.
  function collectAllPaths(begin, end) {
    var stack = new go.List(go.Node);
    var coll = new go.List(go.List);

    function find(source, end) {

      source.findNodesOutOf().each(function(n) {

       
        // console.log()

        if (n === source) return;  // ignore reflexive links
        if (n === end) {  // success
          var path = stack.copy();
          path.add(end);  // finish the path at the end node
          coll.add(path);  // remember the whole path
          //alert(1)

        } else if (!stack.contains(n)) {  // inefficient way to check having visited
          stack.add(n);  // remember that we've been here for this path (but not forever)
          find(n, end);
          stack.removeAt(stack.count - 1);
         



        }  // else might be a cycle
          
    

      });
    }

    stack.add(begin);  // start the path at the begin node
    find(begin, end);
    // console.log(coll.n)
      begin.findNodesOutOf().each(function(n) {
         checking = false;

     checking = checkingMains(coll,n)
         
      // console.log(checking)
      //     console.log(n.key)
    if (checking) {
         
          var node = myDiagram.findNodeForKey(n.key);
          if (node !== null) {
            myDiagram.startTransaction();
            myDiagram.remove(node);
            myDiagram.commitTransaction("deleted node");
          } 

        }else{
          // console.log('else')
        }


      });

    return coll;
  }
function checkingMains(coll,n){
  
   $.each(coll.n,function(indx,nVal) {
 // console.log('-------------------')
 //   console.log(nVal)
      checking = checkPathNodes(nVal,n)
    
      // console.log(checking)
      //    console.log(indx)
      // console.log('-------------------')
   
   if (checking == false) {
    return false;
   }else{
    return true;
   }
         
      })
return checking;
}
function checkPathNodes(nVal,n){
    $.each(nVal.n,function(indx1,nValIn) {
           // check key in container

           if(nValIn.key != "undefined"){

         // console.log(n.key +"!="+ nValIn.key)
          if(n.key != nValIn.key){
              checking = true;
              // 
           }else{
            checking = false;
            return checking;

           }
           }
          

 
        })
 return checking;
}
  // Return a string representation of a path for humans to read.
  function pathToString(path) {
    var s = path.length + ":- ";
    
    for (var i = 0; i < path.length; i++) {
      // console.log(path.elt(i).data)
      if (i > 0) s += " --> ";
      s += path.elt(i).data.key;
    }

    return s;
  }


  // When a node is selected show distances from the first selected node.
  // When a second node is selected, highlight the shortest path between two selected nodes.
  // If a node is deselected, clear all highlights.
  function nodeSelectionChanged(node) {
    // console.log('node')

    var diagram = node.diagram;
       // console.log(diagram)  
    if (diagram === null) return;
    diagram.clearHighlighteds();
    if (node.isSelected) {
      // when there is a selection made, always clear out the list of all paths
      var sel = document.getElementById("myPaths");
      sel.innerHTML = "";

      // show the distance for each node from the selected node
      var begin = diagram.selection.first();
      showDistances(begin);

      if (diagram.selection.count === 2) {
        var end = node;  // just became selected

        listAllPaths(begin, end);
        // highlight the shortest path
        highlightShortestPath(begin, end);

        // list all paths
      
      }
    }


  }


  // Have each node show how far it is from the BEGIN node.
  function showDistances(begin) {
    // compute and remember the distance of each node from the BEGIN node
    distances = findDistances(begin);
    // console.log("distances")
    // console.log(distances)
    // show the distance on each node
    var it = distances.iterator;
    while (it.next()) {
      var n = it.key;
      var dist = it.value;
      myDiagram.model.setDataProperty(n.data, "distance", dist);
    }
  }


  // Highlight links along one of the shortest paths between the BEGIN and the END nodes.
  // Assume links are unidirectional.
  function highlightShortestPath(begin, end) {
    // highlightPath(findShortestPath(begin, end));
    $("#myPaths").find('option').each(function(indx,val){

      // console.log(val)
    var idx = indx;
    var opt = val;
    var val = val;
    // highlightPath(paths.elt(indx));
    path = paths.elt(indx)
     for (var i = 0; i < path.count - 1; i++) {
      var f = path.elt(i);
      var t = path.elt(i + 1);
      f.findLinksTo(t).each(function(l) { l.isHighlighted = true; });
    }

 })
  }


  // List all paths from BEGIN to END
  function listAllPaths(begin, end) {

    // compute and remember all paths from BEGIN to END: Lists of Nodes
    paths = collectAllPaths(begin, end);
    console.log("paths")
    console.log(paths)
    // update the Selection element with a bunch of Option elements, one per path
    var sel = document.getElementById("myPaths");
    sel.innerHTML = "";  // clear out any old Option elements
      
    paths.each(function(p) {
      var opt = document.createElement("option");
      opt.text = pathToString(p);
      sel.add(opt, null);
    });
    sel.onchange = highlightSelectedPath;

    $('#pathCount').html(paths.length)

  }

  // A collection of all of the paths between a pair of nodes, a List of Lists of Nodes
  var paths = null;
  // This is only used for listing all paths for the selection onchange event.

  // When the selected item changes in the Selection element,
  // highlight the corresponding path of nodes.
  function highlightSelectedPath() {
    var sel = document.getElementById("myPaths");
    var idx = sel.selectedIndex;
    var opt = sel.options[idx];
    var val = opt.value;
    highlightPath(paths.elt(sel.selectedIndex));
  }

  // Highlight a particular path, a List of Nodes.
  function highlightPath(path) {
    // alert()
    myDiagram.clearHighlighteds();
    for (var i = 0; i < path.count - 1; i++) {
      var f = path.elt(i);
      var t = path.elt(i + 1);
      f.findLinksTo(t).each(function(l) { l.isHighlighted = true; });
    }


  }


//// delete un linked nodes
function deleteNode()
{
    // TAKE NOTE - This will get all selections so you need to handel  this
    // If you have multiple select enabled
    var diagram =myDiagram//.diagram.selection.first();   
    // console.log(diagram) 
    // console.log(diagram.selection.first()) 
    var childNodes = getChildNodes(diagram.selection.first());

    //Remove linked children
    $.each(childNodes, function()
    {
        myDiagram.remove(this);
    });

    // Then also delete the actual node after the children was deleted
    // TAKE NOTE - This will delete all selections so you need to handle this
    // If you have multiple select enabled
   myDiagram.commandHandler.deleteSelection();
}
function getChildNodes(deleteNode)
{
    var children = [];
    var allConnected= deleteNode.findNodesConnected();

    while (allConnected.next())
    {
        var child = allConnected.value;

        // Check to see if this node is a child:
        if (isChildNode(deleteNode, child))
        {
            // add the current child
            children.push(child);
            // console.log("child")
            // console.log(child)
            // Now call the recursive function again with the current child
            // to get its sub children
            var subChildren = getChildrenNodes(child);

            // add all the children to the children array
            $.each(subChildren, function()
            {
                children.push(this);
            });
       }
   }

    // return the children array
    return children;
}
function isChildNode(currNode, currChild)
{
    var links = myDiagram.links.iterator;
    while (links.next())
    {
        // Here simply look at the link to determine the direction by checking the direction against the currNode and the child node. If from is the current node and to the child node
        // then you know its a vhild
        var currentLinkModel = links.value.data;
        if (currentLinkModel.from === currNode.data.key &&   currentLinkModel.to === currChild.data.key)
        {
             return true;
        }
    }
    return false;
}
//////////////////////////
  
$(document).ready(function(){

var iframeError;

$('#liveBtn').click(function () {

    var action_data = $(this).attr('data-action')
    // alert(action_data)
    if(action_data == 0){
        $('#liveBtn').removeClass("btn-danger").addClass("btn-success")
        $('#liveBtn').attr("data-action","1")  
        action_data=1

        interval = setInterval(function(){
        console.log("ref start, action_data= "+action_data)
        chrome.storage.sync.get(["testing_url_file", "testing_status"], function (res) {
  file_url = (res.testing_url_file)
  jQuery.getJSON(file_url, load);
})
 function load(jsondata) {
    // create the model from the data in the JavaScript object parsed from JSON text
    myDiagram.model = new go.GraphLinksModel(jsondata["nodes"], jsondata["links"]);


// myDiagram.commandHandler.selectAll();
// myDiagram.selectCollection({key:'http://localhost/testing/',key:'http://localhost/testing/'});
myDiagram.select(myDiagram.findNodeForKey(jsondata["nodes"][0]['key']));
// myDiagram.select(myDiagram.findNodeForKey("http://localhost/testing2/"));


  // updateHighlights('linksIn')
deleteNode();

  }
        }, 3000)

    }else{
       
        $('#liveBtn').removeClass("btn-success").addClass("btn-danger")
        $('#liveBtn').attr("data-action","0")
        action_data=0
        clearInterval(interval)

    }
});
$('#expSubModel').click(function () {

  
  $('#runTestCasesModal').modal('show')
})

$('#testCaseRunBtn').click(function () {
      var tc;
    stopLoopMsg = ""
    $("#myPaths").find('option').each(function(indx,val){
      tc = val.text.split(':-')[1];
      str = ""
     
      stopLoop=0;
      stopLoopInc=1;
      $.each(tc.split('-->'),function(index,urls){
         // console.log(urls)
         if (stopLoop == 0){
          $.ajax({
    type: "GET", url: urls,async:false,
    success: function (data, text) {
                str += "<span class='label label-primary' style='font-size:17px;'>"+urls+"</span> -->"
                stopLoop=0;
                
                $("#iframe_a_src").html(urls);
                $("#iframe_a").attr("src", urls);
    },
    error: function (request, status, error) {
               str += "<span class='label label-danger' style='font-size:17px;'>"+urls+"</span> -->"
              stopLoop = 1;
              stopLoopInc++;
              stopLoopMsg += "Path : "+(indx+1)+" -- ";
        // alert(request.responseText);
    }
});
        }



          

      })
     $('.testCaseRun').append("<br>Path "+(indx+1)+" : "+str+"<br>")
     if (stopLoopInc > 0)
     $('.testCaseRunMsg').html("<br>System finds ( "+stopLoopInc+" ) fault(s).<br>"+stopLoopMsg)
     console.log('------------------------------------')
 })




})


  $('#genSubModel').click(function(){
  
    $("#myPaths").find('option').each(function(indx,val){

      // console.log(val)
    var idx = indx;
    var opt = val;
    var val = val;
    // highlightPath(paths.elt(indx));
    path = paths.elt(indx)
     for (var i = 0; i < path.count - 1; i++) {
      var f = path.elt(i);
      var t = path.elt(i + 1);
      f.findLinksTo(t).each(function(l) { l.isHighlighted = true; });
    }

 })
  //   var sel = document.getElementById("myPaths");
  //   var idx = val.selectedIndex;
  //   var opt = val.options[idx];
  //   var val = opt.value;
  //   highlightPath(paths.elt(val.selectedIndex));

 
  })
  //////////
  $('#bestSubModel').click(function(){
        myDiagram.clearHighlighteds();
 // alert($("#myPaths option").html())
    var comp = $("#myPaths option").html().split(':')[0];
   
    var indexId = 0;
    $("#myPaths").find('option').each(function(indx,val){
      if (comp > val.text.split(':')[0]) {
        comp = val.text.split(':')[0];
        indexId = indx
      }
    
  
 


 })
      // highlightPath(paths.elt(indx));
    path = paths.elt(indexId)
     for (var i = 0; i < path.count - 1; i++) {
      var f = path.elt(i);
      var t = path.elt(i + 1);
      f.findLinksTo(t).each(function(l) { l.isHighlighted = true; });
    }
  //   var sel = document.getElementById("myPaths");
  //   var idx = val.selectedIndex;
  //   var opt = val.options[idx];
  //   var val = opt.value;
  //   highlightPath(paths.elt(val.selectedIndex));


  })  
  //////////
  $('#LONGSubModel').click(function(){
        myDiagram.clearHighlighteds();

    var comp = 0;
    var indexId = 0;
    $("#myPaths").find('option').each(function(indx,val){
      if (comp < val.text.split(':-')[0]) {
        comp = val.text.split(':-')[0];
        indexId = indx
      }
    // valuesp = val.text.split(':-')[1].split('-->');
// alert(valuesp[0])
    // myDiagram.select(myDiagram.findNodeForKey(valuesp[0]));

  

 })
      // highlightPath(paths.elt(indx));
    path = paths.elt(indexId)
     for (var i = 0; i < path.count - 1; i++) {
      var f = path.elt(i);
      var t = path.elt(i + 1);
      f.findLinksTo(t).each(function(l) { l.isHighlighted = true; });
    }

  })
  //////////


  //////////
  $('#clearSubModel').click(function(){
   // console.log(myDiagram.model.toJson())


        myDiagram.clearHighlighteds();

  // diagram.model = new go.TreeModel(myDiagram);
    document.getElementById("mySavedModel").innerHTML = myDiagram.model.toJson();


  })
    //////////
  $('#saveSubModel').click(function(){
    // alert()
    myDiagram.zoomToFit();

var diaWidth=63431, diaHeight=1010;
var test= myDiagram.makeImageData({
background: "white",
scale: 1,
type: "image/jpeg",
maxSize: new go.Size(diaWidth, diaHeight)
});



  })
  $('#resetSubModel').click(function(){
   // console.log(myDiagram.model.toJson())
chrome.storage.sync.get(["testing_url_file", "testing_status"], function (res) {
  file_url = (res.testing_url_file)
  jQuery.getJSON(file_url, load);
})
 function load(jsondata) {
    // create the model from the data in the JavaScript object parsed from JSON text
    myDiagram.model = new go.GraphLinksModel(jsondata["nodes"], jsondata["links"]);


// myDiagram.commandHandler.selectAll();
// myDiagram.selectCollection({key:'http://localhost/testing/',key:'http://localhost/testing/'});
myDiagram.select(myDiagram.findNodeForKey(jsondata["nodes"][0]['key']));
// myDiagram.select(myDiagram.findNodeForKey("http://localhost/testing2/"));


  // updateHighlights('linksIn')
deleteNode();
}
  })
    //////////
  $('#imgSubModel').click(function(){
// myDiagram.makeImage({
//   size: new go.Size(100,100)
// });
var newWindow = window.open("","newWindow");
  if (!newWindow) return;
  var newDocument = newWindow.document;
  var svg = myDiagram.makeSvg({
    document: newDocument,  // create SVG DOM in new document context
    scale: 9,
    maxSize: new go.Size(600, 600)
  });
  newDocument.body.html(svg);
  })
  //////////
})

function loadIframe(e){
    
 
}
function errorIframe(e){
    alert('error '+e);
}
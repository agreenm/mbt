// receive part of caaling form popup
// we send from popup.js and with passing parem of ext url
// lets start
// alert('content')

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        rootDomain = window.location.href;
        rootDomainName = document.title
        // alert("Starting....")
       // console.log(rootDomain)
    // window.open("http://"+request.urlToModel)
$("document").ready(function () {
    //  alert('12')
     var nodes = '{ "nodes" : [';
     var links = ' "links" : [';
    nodes += '{ "key":"' + rootDomain + '","title":"' + rootDomain.replace(/\s/g,'') + '", "color":"gray" },'
    // links += ` { "from": "` + rootDomain + `", "to": "` + rootDomain + `" },`
    var inc = 0
    $('body').find('a').each(function (ind, val) {
     
        //console.log($(this))
        // higlight anchors
        $(this).css({
            'border': '2px solid red',
            'background': 'pink',
            'opacity': '0.5'
        })
    /////////////////////////////////////////////
    // print urls in console port of browser
//    console.log($(this)[0].href.replace(/\s/g,''))
    // node creation
    // console.log($(this).text())
    // if (!/\s/.test($(this).text())) {
        
    
        nodes += '{ "key":"' + $(this)[0].href.replace(/\s/g, '') + '","title":"' + $(this).text().replace(/\s/g,'')  + '", "color":"silver" },'
    /////
    ///// creating links 
    // #1 we have to set root
    // #2 parent and childreen nodes
    // #3 self calling : return to itself
    // #4 return from child to parent
    links += ` { "from": "` + rootDomain + `", "to": "` + $(this)[0].href.replace(/\s/g,'') + `" },`

    // generating child nodes
        // if (condition) {
            
        // }
        // console.log($(this))
       createChildNodesWithLinks(10,$(this)[0].href, $(this)[0].text, rootDomain, $(this)[0].origin);
 
      
    // }
    // generating child nodes

    })
    // remove last comma
    nodes = nodes.slice(0, -1);
    nodes += ']';
    
   

function createChildNodesWithLinks(inc,parentUrl, Titletext, rootDomain, baseUrl) {
    // alert(inc)
// console.log(inc)
    if (inc <= 0) {
        // alert("OPPS BREAKING LOOP")
        return false;
    }
// alert(1)
//   if (parentUrl.includes("#")) {
//       // alert(1)
//       parentUrl = parentUrl.slice(0, -1)
//   }
    if (parentUrl != "" && parentUrl != "#") {
        // alert(2)
//  console.log('call')
        $.ajax({
            async: false,
            'url': parentUrl,
            success: function (Result) {
                // alert(3)
                // console.log('--------------------' + parentUrl + '-------------------------')
                // console.log($.parseHTML(Result))
                // console.log('-------------------------------------------------------------')
               // Result = Result.stringify();
                 rootDomain = parentUrl
                 
                $($.parseHTML(Result)).filter('a').each(function (ind, val) {
            //    $(Result).find('a').each(function (ind, val) {
                    // alert()
                    //   console.log('--------------------each-------------------------')
                    // console.log("text=" + $(this).text());
                    // console.log(!/\s/.test($(this).text()))
                    //       console.log('---------------------------------------------')
                    if ($(this).text() !== "") {
                        
                        /*
                                    (parent)
                                    /         \
                                   /           \
                                  (child 1)   (child 2)
                                   /
                                  /
                                 (child 2)
                        
                        */
                        
                        
                        parentUrl = $(this)[0].href
                          if ($(this)[0].text.trim() == "") {
                              Titletext = parentUrl
                        }else{
                              Titletext = $(this)[0].text.trim()
                        }
                       

                        baseUrlOLD = baseUrl
                        baseUrl = $(this)[0].origin
                        console.log(baseUrl.trim() + "===" + baseUrlOLD)
                        if (baseUrl.trim() === baseUrlOLD) {
                       //   console.log('equal');
                            nodes += '{ "key":"' + parentUrl + '","title":"' + Titletext.replace(/\s/g,'') + '", "color":"#f9f9f9" },'
                           links += ` { "from": "` + rootDomain + `", "to": "` + parentUrl + `" },`
                        //   alert("done=")
                        //   alert("done="+baseUrl)
                       createChildNodesWithLinks(inc-1,parentUrl, Titletext, rootDomain, baseUrl);
                        }else{      
                            //   alert('not equal'+baseUrl)                       
                        //    console.log('not equal');
                            //  return false;
                        }

                       }else{
                        //    alert("not in cond="+baseUrl) 
                        //   console.log('not in cond')
                       }
                      

                       
                    
                    //    })
                })
            }

        })
    }else{
        console.log("empty")
    }
}



    //// links
    links = links.slice(0, -1);
    links += ']}';
    ///
    tree = nodes + "," + links;
   // console.log(tree)

  saveTextAsFile1(tree)
  alert('Fiished Successfully')
    //  window.reload($('#urlTesting').val());
  $('#loader').hide()
  window.open("http://localhost/mscproject/gojs/ex.html")
})

function saveTextAsFile() {
    var textToWrite = document.getElementById("inputTextToSave").value;
    var textFileAsBlob = new Blob([textToWrite], {
        type: 'text/plain'
    });
    var fileNameToSaveAs = document.getElementById("inputFileNameToSaveAs").value;
    var downloadLink = document.createElement("a");
    downloadLink.download = fileNameToSaveAs;
    downloadLink.innerHTML = "Download File";
    if (window.webkitURL != null) {
        // Chrome allows the link to be clicked
        // without actually adding it to the DOM.
        downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
    } else {
        // Firefox requires the link to be added to the DOM
        // before it can be clicked.
        downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
        downloadLink.onclick = destroyClickedElement;
        downloadLink.style.display = "none";
        document.body.appendChild(downloadLink);
    }

    downloadLink.click();
}

function saveTextAsFile1(tree) {
    var textToSave = tree
    var textToSaveAsBlob = new Blob([textToSave], {
        type: "text/plain"
    });
    var textToSaveAsURL = window.URL.createObjectURL(textToSaveAsBlob);
    var fileNameToSaveAs = '/Applications/MAMP/htdocs/mscproject/gojs/minimal.json'

    var downloadLink = document.createElement("a");
    downloadLink.download = fileNameToSaveAs;
    downloadLink.innerHTML = "Download File";
    downloadLink.href = textToSaveAsURL;
    downloadLink.onclick = destroyClickedElement;
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
}
function destroyClickedElement(event) {
    document.body.removeChild(event.target);
}



    });


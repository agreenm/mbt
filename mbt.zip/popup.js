// alert('popup')

// chrome.runtime.onMessage.addListener(
//     function (request, sender, sendResponse) {
//         if (request.msg === "something_completed") {
//             //  To do something
//             console.log(request.data.subject)
//             console.log(request.data.content)
//         }
//     }
// );



    $("document").ready(function () {
   


           chrome.tabs.query({
               active: true,
               currentWindow: true
           }, function (tabs) {
            //    alert(tabs[0].url)
                        chrome.storage.sync.set({"testing_url": tabs[0].url});
           });


        chrome.storage.sync.get(["testing_url","testing_status"], function (res) {           
            // $("#centent").html(res.testing_status)
            // alert(JSON.stringify(res))
            if (res.testing_status == 1) {
                $("#startTesting").css({"background":"red","color":"white"})
                $("#startTesting").html("Stop")
            }else{
                $("#startTesting").css({"background":"green","color":"white"})
                $("#startTesting").html("Start")}
        })



        $('#startTesting').click(function () {
        chrome.storage.sync.get(["testing_url", "testing_status"], function (res) {
          
            // $("#centent").html(res.testing_url)
            $("#startTesting").css({"background":"green","color":"white"})
          $("#startTesting").html("Start")
          //alert(res.testing_status)
            if (res.testing_status == 0) {
                // alert(11)
                $("#startTesting").css({"background":"red","color":"white"})
                $("#startTesting").html("Stop")
                chrome.storage.sync.set({"testing_status":1});
                 
            }else{
                chrome.storage.sync.set({"testing_status":0});
               // $("#centent").html("")
}
           })
        //    $('#loader').show()
       var msg = {
                    screenshotUrl: '',
                    type: 'reload'
                }
                chrome.tabs.query({
                    currentWindow: true,
                    active: true
                }, function (tabs) {
                    var activeTab = tabs[0];
                    chrome.tabs.sendMessage(activeTab.id, msg);
                });

            return false;
        })
    })



    var indexedDB = window.indexedDB || window.webkitIndexedDB ||
        window.mozIndexedDB || window.msIndexedDB;
    var IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction;
    var db;
    var request;
    (function () {


        function contentLoaded() {
            //  alert("CONTET")
            // initDb();

          
            $('#DownloadFile').click(function () {
                //  alert('a')
                var msg = {
                    screenshotUrl: '',
                    type: 'get_data'
                }
                chrome.tabs.query({
                    currentWindow: true,
                    active: true
                }, function (tabs) {
                    var activeTab = tabs[0];
                    chrome.tabs.sendMessage(activeTab.id, msg);
                });
                // return false;
            })
          
            $('#LiveMBT').click(function () {
                //  alert('a')
                var txt;
var r = confirm("Are You Sure to clean the database");
if (r == true) {
                  var msg = {
                    screenshotUrl: '',
                    type: 'delete_database'
                }
                chrome.tabs.query({
                    currentWindow: true,
                    active: true
                }, function (tabs) {
                    var activeTab = tabs[0];
                    chrome.tabs.sendMessage(activeTab.id, msg);

                });
} else {
}


                // return false;
            })
                 $('#LiveMBTView').click(function () {
                    chrome.tabs.create({url: chrome.extension.getURL('mbt/mbt.html')});

            })

        }

        window.addEventListener("DOMContentLoaded", contentLoaded, false);
    })();